import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { 
  Github, 
  Linkedin, 
  Mail, 
  Phone, 
  MapPin, 
  Download,
  Code,
  Database,
  Globe,
  Award,
  GraduationCap,
  Briefcase,
  Star,
  Calendar,
  ExternalLink,
  User,
  ChevronDown,
  Menu,
  X,
  Heart,
  Coffee
} from 'lucide-react';

const Index = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrollY, setScrollY] = useState(0);
  const [activeSection, setActiveSection] = useState('home');
  const [currentGreeting, setCurrentGreeting] = useState('');

  const greetings = [
    "Namaste! Welcome to my portfolio 🙏",
    "Hello! Great to see you here! 👋",
    "Hi there! Thanks for visiting! 😊",
    "Welcome! Let's explore together! ✨"
  ];

  useEffect(() => {
    // Set random greeting on component mount
    setCurrentGreeting(greetings[Math.floor(Math.random() * greetings.length)]);
    
    const handleScroll = () => {
      setScrollY(window.scrollY);
      
      // Update active section based on scroll position
      const sections = ['home', 'about', 'skills', 'projects', 'experience', 'contact'];
      const scrollPos = window.scrollY + 100;
      
      for (let section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (scrollPos >= offsetTop && scrollPos < offsetTop + offsetHeight) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  const skills = [
    { name: 'C/C++', level: 85, category: 'Programming', icon: '💻' },
    { name: 'Python', level: 80, category: 'Programming', icon: '🐍' },
    { name: 'Windows', level: 90, category: 'Operating Systems', icon: '🪟' },
    { name: 'Microsoft Office', level: 85, category: 'Tools & Software', icon: '📊' },
    { name: 'Problem Solving', level: 88, category: 'Soft Skills', icon: '🧩' },
    { name: 'Quick Learner', level: 90, category: 'Soft Skills', icon: '🚀' }
  ];

  const projects = [
    {
      title: 'Advanced Calculator',
      description: 'A comprehensive calculator application with advanced mathematical operations built in C & C++',
      technologies: ['C', 'C++', 'Data Structures'],
      status: 'Completed',
      year: '2024'
    },
    {
      title: 'Student Grade System',
      description: 'Academic grade management system with percentage calculations and file handling',
      technologies: ['C++', 'File Handling', 'Logic Building'],
      status: 'Completed',
      year: '2024'
    },
    {
      title: 'Multiplication Tables',
      description: 'Dynamic table generation tool for educational purposes with loop optimization',
      technologies: ['C', 'Loops', 'Mathematical Logic'],
      status: 'Completed',
      year: '2024'
    }
  ];

  const experiences = [
    {
      title: 'Google Cloud Arcade Participant',
      company: 'Google',
      duration: 'April 2025',
      type: 'Program',
      description: 'Gained hands-on experience with cloud technologies and modern development practices',
      skills: ['Cloud Computing', 'DevOps', 'Modern Development']
    },
    {
      title: 'Hackathon Bootcamp Attendee',
      company: 'Tech Community',
      duration: 'Jan 2025',
      type: 'Event',
      description: 'Enhanced problem-solving skills and learned collaborative development practices',
      skills: ['Team Collaboration', 'Problem Solving', 'Rapid Development']
    }
  ];

  return (
    <div className="min-h-screen bg-gray-900 text-white overflow-x-hidden">
      {/* Animated Background Grid */}
      <div className="fixed inset-0 opacity-10 pointer-events-none">
        <div 
          className="absolute inset-0 bg-gradient-to-br from-blue-600/20 via-purple-600/20 to-cyan-600/20"
          style={{
            backgroundImage: `
              linear-gradient(rgba(59, 130, 246, 0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(59, 130, 246, 0.1) 1px, transparent 1px)
            `,
            backgroundSize: '50px 50px',
            transform: `translate(${scrollY * 0.1}px, ${scrollY * 0.05}px)`
          }}
        />
      </div>

      {/* Greeting Banner */}
      <div className="fixed top-0 left-0 right-0 z-40 bg-gradient-to-r from-blue-600/90 via-purple-600/90 to-cyan-600/90 backdrop-blur-md text-center py-2 text-sm font-medium animate-pulse">
        <div className="flex items-center justify-center space-x-2">
          <Heart className="w-4 h-4 text-red-400 animate-bounce" />
          <span>{currentGreeting}</span>
          <Coffee className="w-4 h-4 text-yellow-400 animate-bounce" />
        </div>
      </div>

      {/* Floating Navigation */}
      <nav className="fixed top-16 left-1/2 transform -translate-x-1/2 z-50 bg-gray-800/80 backdrop-blur-md rounded-full px-6 py-3 border border-gray-700/50 transition-all duration-300 hover:bg-gray-800/90">
        <div className="flex items-center space-x-6">
          <div className="hidden md:flex space-x-6">
            {['home', 'about', 'skills', 'projects', 'experience', 'contact'].map((section) => (
              <button
                key={section}
                onClick={() => scrollToSection(section)}
                className={`capitalize text-sm font-medium transition-all duration-300 px-3 py-1 rounded-full ${
                  activeSection === section 
                    ? 'bg-blue-500 text-white' 
                    : 'text-gray-300 hover:text-white hover:bg-gray-700/50'
                }`}
              >
                {section}
              </button>
            ))}
          </div>
          
          <button 
            className="md:hidden text-white"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-40 bg-gray-900/95 backdrop-blur-md md:hidden">
          <div className="flex flex-col items-center justify-center h-full space-y-6">
            {['home', 'about', 'skills', 'projects', 'experience', 'contact'].map((section) => (
              <button
                key={section}
                onClick={() => scrollToSection(section)}
                className="capitalize text-xl font-medium text-white hover:text-blue-400 transition-colors duration-300"
              >
                {section}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Hero Section */}
      <section id="home" className="min-h-screen flex items-center justify-center px-4 relative pt-16">
        <div className="text-center max-w-4xl mx-auto">
          {/* Profile Picture with enhanced styling */}
          <div className="mb-8 relative">
            <div className="w-48 h-48 mx-auto relative group">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-cyan-500 rounded-full animate-spin opacity-75 group-hover:opacity-100 transition-opacity duration-300" style={{ animationDuration: '3s' }}></div>
              <div className="absolute inset-2 bg-gray-900 rounded-full overflow-hidden">
                <Avatar className="w-full h-full">
                  <AvatarImage 
                    src="/lovable-uploads/0264a09e-016e-4f85-a741-ca9f9a7043a9.png" 
                    alt="Vansh Jaiswal"
                    className="object-cover w-full h-full hover:scale-110 transition-transform duration-500"
                  />
                  <AvatarFallback className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                    VJ
                  </AvatarFallback>
                </Avatar>
              </div>
              {/* Floating elements around photo */}
              <div className="absolute -top-4 -right-4 w-8 h-8 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></div>
              <div className="absolute -bottom-4 -left-4 w-6 h-6 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.5s' }}></div>
              <div className="absolute top-1/2 -left-8 w-4 h-4 bg-cyan-500 rounded-full animate-bounce" style={{ animationDelay: '1s' }}></div>
            </div>
          </div>
          
          {/* Enhanced Welcome Message */}
          <div className="space-y-6 mb-8">
            <div className="text-lg md:text-xl text-blue-400 font-medium animate-fade-in">
              <span className="inline-flex items-center space-x-2">
                <span>👋</span>
                <span>Welcome to my digital world!</span>
              </span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold mb-6 animate-fade-in">
              <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent">
                Vansh Jaiswal
              </span>
            </h1>
            
            <div className="text-xl md:text-2xl text-gray-300 mb-8">
              <div className="typing-animation">
                Aspiring Computer Science Student & Developer
              </div>
            </div>

            {/* Fun intro message */}
            <div className="bg-gray-800/50 backdrop-blur-sm rounded-lg p-4 max-w-2xl mx-auto border border-gray-700/50 animate-fade-in">
              <p className="text-gray-300 leading-relaxed">
                <span className="text-yellow-400">🚀</span> Passionate about coding, problem-solving, and creating innovative solutions. 
                <span className="text-green-400"> Currently exploring</span> the endless possibilities in technology!
              </p>
            </div>
          </div>
          
          {/* Animated Buttons */}
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            <Button 
              onClick={() => window.open('mailto:vanshjaiswalofficial@gmail.com')}
              className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 transform hover:scale-105 transition-all duration-300"
            >
              <Mail className="w-4 h-4 mr-2" />
              Let's Talk
            </Button>
            <Button 
              onClick={() => window.open('tel:+918103107203')}
              className="bg-gradient-to-r from-green-500 to-teal-600 hover:from-green-600 hover:to-teal-700 transform hover:scale-105 transition-all duration-300"
            >
              <Phone className="w-4 h-4 mr-2" />
              Call Now
            </Button>
            <Button 
              className="bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 transform hover:scale-105 transition-all duration-300"
            >
              <Download className="w-4 h-4 mr-2" />
              Download CV
            </Button>
          </div>
          
          {/* Scroll Indicator */}
          <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
            <div className="flex flex-col items-center space-y-2">
              <span className="text-xs text-gray-400">Scroll to explore</span>
              <ChevronDown className="w-6 h-6 text-gray-400" />
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12 animate-fade-in">
            <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              About Me
            </span>
          </h2>
          
          <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700 hover:bg-gray-800/70 transition-all duration-500 transform hover:-translate-y-2">
            <CardContent className="p-8">
              <div className="grid md:grid-cols-2 gap-8 items-center">
                <div className="space-y-4">
                  <h3 className="text-2xl font-semibold text-white mb-4">Career Objective</h3>
                  <p className="text-gray-300 leading-relaxed">
                    Aspiring Computer Science student with a strong foundation in programming and problem-solving, 
                    seeking opportunities to grow in full-stack development and participate in real-world projects and hackathons.
                  </p>
                  <div className="flex items-center text-gray-300 mt-4">
                    <MapPin className="w-5 h-5 mr-2 text-blue-400" />
                    R-256, Kalindi Gol City, Bhangya, Indore (M.P.)
                  </div>
                </div>
                <div className="space-y-4">
                  {[
                    { skill: 'Problem Solving', level: 'Expert' },
                    { skill: 'Programming', level: 'Advanced' },
                    { skill: 'Quick Learning', level: 'Expert' }
                  ].map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg hover:bg-gray-700 transition-colors duration-300">
                      <span className="text-white">{item.skill}</span>
                      <Badge className="bg-gradient-to-r from-green-500 to-blue-500">{item.level}</Badge>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 px-4 bg-gray-800/30">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12">
            <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              Skills & Expertise
            </span>
          </h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {skills.map((skill, index) => (
              <Card 
                key={index} 
                className="bg-gray-800/50 backdrop-blur-sm border-gray-700 hover:bg-gray-800/70 transition-all duration-500 transform hover:-translate-y-2 group"
              >
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <span className="text-2xl">{skill.icon}</span>
                      <h4 className="font-semibold text-white">{skill.name}</h4>
                    </div>
                    <span className="text-sm text-blue-400 font-bold">{skill.level}%</span>
                  </div>
                  
                  <div className="w-full bg-gray-700 rounded-full h-3 mb-3 overflow-hidden">
                    <div 
                      className="bg-gradient-to-r from-blue-500 to-purple-600 h-3 rounded-full transition-all duration-1000 ease-out transform group-hover:scale-x-105"
                      style={{ 
                        width: `${skill.level}%`,
                        animation: `skillBar 2s ease-out ${index * 0.2}s both`
                      }}
                    />
                  </div>
                  
                  <Badge variant="outline" className="text-xs border-gray-600 text-gray-300">
                    {skill.category}
                  </Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12">
            <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              Featured Projects
            </span>
          </h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map((project, index) => (
              <Card 
                key={index} 
                className="bg-gray-800/50 backdrop-blur-sm border-gray-700 hover:bg-gray-800/70 transition-all duration-500 transform hover:-translate-y-4 group cursor-pointer"
              >
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-white flex items-center">
                      <Code className="w-5 h-5 mr-2 text-blue-400" />
                      {project.title}
                    </CardTitle>
                    <ExternalLink className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300 text-blue-400" />
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge className="bg-green-500/20 text-green-400 border-green-400">{project.status}</Badge>
                    <span className="text-xs text-gray-400">{project.year}</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300 mb-4 leading-relaxed">{project.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {project.technologies.map((tech, techIndex) => (
                      <Badge 
                        key={techIndex} 
                        variant="outline" 
                        className="border-gray-600 text-gray-300 hover:bg-gray-700 transition-colors duration-300"
                      >
                        {tech}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="py-20 px-4 bg-gray-800/30">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12">
            <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              Experience & Activities
            </span>
          </h2>
          
          <div className="space-y-6">
            {experiences.map((exp, index) => (
              <Card 
                key={index} 
                className="bg-gray-800/50 backdrop-blur-sm border-gray-700 hover:bg-gray-800/70 transition-all duration-500 transform hover:-translate-y-2"
              >
                <CardHeader>
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                    <CardTitle className="text-white flex items-center mb-2 md:mb-0">
                      <Briefcase className="w-6 h-6 mr-3 text-blue-400" />
                      <div>
                        <div>{exp.title}</div>
                        <div className="text-sm text-gray-400 font-normal">{exp.company}</div>
                      </div>
                    </CardTitle>
                    <div className="flex items-center space-x-2">
                      <Badge className="bg-gradient-to-r from-purple-500 to-pink-500">{exp.type}</Badge>
                      <span className="text-sm text-gray-400">{exp.duration}</span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300 mb-4">{exp.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {exp.skills.map((skill, skillIndex) => (
                      <Badge 
                        key={skillIndex}
                        variant="outline" 
                        className="border-gray-600 text-gray-300"
                      >
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-8">
            <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              Let's Connect
            </span>
          </h2>
          
          <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700 hover:bg-gray-800/70 transition-all duration-500">
            <CardContent className="p-8">
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div className="flex items-center text-gray-300 hover:text-white transition-colors duration-300 cursor-pointer p-3 rounded-lg hover:bg-gray-700/50">
                    <Mail className="w-5 h-5 mr-3 text-blue-400" />
                    vanshjaiswalofficial@gmail.com
                  </div>
                  <div className="flex items-center text-gray-300 hover:text-white transition-colors duration-300 cursor-pointer p-3 rounded-lg hover:bg-gray-700/50">
                    <Phone className="w-5 h-5 mr-3 text-green-400" />
                    +918103107203
                  </div>
                  <div className="flex items-center text-gray-300 hover:text-white transition-colors duration-300 cursor-pointer p-3 rounded-lg hover:bg-gray-700/50">
                    <MapPin className="w-5 h-5 mr-3 text-red-400" />
                    Indore, Madhya Pradesh
                  </div>
                </div>
                <div className="space-y-4">
                  <Button 
                    onClick={() => window.open('https://github.com', '_blank')}
                    className="w-full bg-gradient-to-r from-gray-700 to-gray-800 hover:from-gray-600 hover:to-gray-700 transform hover:scale-105 transition-all duration-300"
                  >
                    <Github className="w-4 h-4 mr-2" />
                    GitHub Profile
                  </Button>
                  <Button 
                    onClick={() => window.open('https://linkedin.com', '_blank')}
                    className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-500 hover:to-blue-600 transform hover:scale-105 transition-all duration-300"
                  >
                    <Linkedin className="w-4 h-4 mr-2" />
                    LinkedIn Profile
                  </Button>
                  <Button 
                    onClick={() => scrollToSection('home')}
                    variant="outline"
                    className="w-full border-gray-600 hover:bg-gray-700 transform hover:scale-105 transition-all duration-300"
                  >
                    Back to Top
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 text-center text-gray-400 border-t border-gray-700/50 bg-gray-800/30">
        <p className="hover:text-white transition-colors duration-300">
          © 2025 Vansh Jaiswal. Crafted with passion for technology. ❤️
        </p>
      </footer>

      {/* Custom Styles */}
      <style dangerouslySetInnerHTML={{
        __html: `
          @keyframes fadeIn {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
          }
          
          @keyframes skillBar {
            from { width: 0%; }
            to { width: var(--target-width); }
          }
          
          .animate-fade-in {
            animation: fadeIn 0.8s ease-out forwards;
          }
          
          .typing-animation {
            overflow: hidden;
            border-right: 2px solid #3b82f6;
            white-space: nowrap;
            animation: typing 3s steps(40, end), blink-caret 0.75s step-end infinite;
          }
          
          @keyframes typing {
            from { width: 0; }
            to { width: 100%; }
          }
          
          @keyframes blink-caret {
            from, to { border-color: transparent; }
            50% { border-color: #3b82f6; }
          }
          
          /* Smooth scrolling */
          html {
            scroll-behavior: smooth;
          }
          
          /* Custom scrollbar */
          ::-webkit-scrollbar {
            width: 8px;
          }
          
          ::-webkit-scrollbar-track {
            background: #1f2937;
          }
          
          ::-webkit-scrollbar-thumb {
            background: linear-gradient(45deg, #3b82f6, #8b5cf6);
            border-radius: 4px;
          }
          
          ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(45deg, #2563eb, #7c3aed);
          }
        `
      }} />
    </div>
  );
};

export default Index;
